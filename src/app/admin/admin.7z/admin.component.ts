import { Component, OnInit } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { CarModel} from './../Classes/CarModel'

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.less'],
  providers: [HttpClient]
})
export class AdminComponent implements OnInit {

  constructor(private http: HttpClient){}

  cars: Array<CarModel> = [];

  ngOnInit() {
  }
  submit(title: string, price: number){
    console.log("hi");
    console.log(title, price);
    const body = {title: title, prise: price};
    this.http.post('http://localhost:5000/admin/model/add_car/', body).subscribe();
  }
  update_list(){
    let cars = [];
    this.http.get('http://localhost:5000/get_cars/').subscribe((response: any) => {
      console.log("response", response);
      this.cars = [];
      response.forEach(element => {
        this.cars.push(element);
      });
    });
    console.log(this.cars);
  }
}
